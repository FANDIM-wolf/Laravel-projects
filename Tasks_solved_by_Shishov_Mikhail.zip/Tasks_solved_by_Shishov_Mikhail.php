<?php 
/*У меня сломался HDD ,поэтому все задачи переписывал по памяти без использования POST и GET 
 , проверить их можно на любом online PHP компиляторе. 
 Михаил Шишов.
*/

// задача 1 блок 1

$num = 23;
if ($num <= 100)
{
    $answer = $num**2;
    echo "Number in 1 task:".$num;
    echo "Answer in 1 task:".$answer;
}


//задача  2 блок 1
$rubles = 5;  // рубли
$cents = 50;  // копейки
$pies = 2     // пирожки

// переводим копейки в рубли и складываем их.
$rubles = $rubles + ($cents/100); 
$answer_2 = $rubles * $pies;


//задача 3 блок 1
$num1 = 5239;
$num1_s = strval($num1);
echo $num1_s." ";
$new_array=array();
for($i=0; $i<=3;$i+1){
    $new_array[$i]= $num1_s[$i]; //записываем в новый массив
    intval($new_array[$i]);
    echo $new_array[$i];
}
for ($j=0;$j<=3;$i+1)
{
    if ($new_array[$i]<=$new_array[$i+1]){
        $temp = $new_array[$i];
        $new_array[$i]=$new_array[$i+1];
        $new_array[$i+1]=$temp;
    }
}
print_r($new_array);
//задача 4 блок 1
$a1=12;
$a2=10;
$a3=5;
//просчитать все возможные пути 
$way1=$a1+$a2+$a3;
$way2=($a1*2)+($a2*2);
$way3=($a1*2)+($a3*2);
$way4=($a2*2)+($a3*2);

// найти наименьший 
$array = array($way1,$way2,$way3,$way4);
$min = 0;
for($i = 0; $i <= 3; $i++){
    if ($min < $array[$i]){
        $min=$array[$i];
        $s = $i;
    }
}
echo $min;
echo "Route:".$s;


//задача 1 блок 2
$k = 25;
$counter = $k;
while($counter!=0){
    $k2 = $k**2;
    $k_s = strval($k);
    $length_of_k_string =strlen($k_s);//локальная переменая для проверки авторморфного числа , используется ниже
    $k2_s =strval($k2);
    $lenght_of_start_checking = strlen($k2_s)-strlen($k); 

    for ($i=$lenght_of_start_checking; $i<= strlen($k2_s); $i++ ){
        if($k_s[$i] == $k2_s[$i]){
            $length_of_k_string=$length_of_k_string-1;
            if($length_of_k_string==0){
                echo "Avtomorfe number:".$k;
                $k = $k-1;
                $counter = $counter -1;
            }
            else{
                if($k_s[$i+1] == $k2_s[$i+1]){
                    $length_of_k_string=$length_of_k_string-1;
                    if($length_of_k_string == 0){
                        echo "Avtomorfe number:".$k;
                        $k = $k-1;
                        $counter = $counter -1; // новая интерация цикла
                    }
                }
             }
        }
    }
}

?>